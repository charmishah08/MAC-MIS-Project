<?php
session_start();
include_once 'include/DB_Functions.php';
$users = new DB_Functions();
?>
<!DOCTYPE html>
<html lang="en">
    <head>
        <meta http-equiv="X-UA-Compatible" content="IE=edge,chrome=1" />
        <meta charset="utf-8" />
        <title>Student Data Upload</title>

        <meta name="description" content="Drag &amp; drop file upload with image preview" />
        <meta name="viewport" content="width=device-width, initial-scale=1.0, maximum-scale=1.0" />

        <!-- bootstrap & fontawesome -->
        <link rel="stylesheet" href="assets/css/bootstrap.min.css" />
        <link rel="stylesheet" href="assets/font-awesome/4.5.0/css/font-awesome.min.css" />

        <!-- page specific plugin styles -->
        <link rel="stylesheet" href="assets/css/dropzone.min.css" />

        <!-- text fonts -->
        <link rel="stylesheet" href="assets/css/fonts.googleapis.com.css" />

        <!-- ace styles -->
        <link rel="stylesheet" href="assets/css/ace.min.css" class="ace-main-stylesheet" id="main-ace-style" />

        <!--[if lte IE 9]>
                <link rel="stylesheet" href="assets/css/ace-part2.min.css" class="ace-main-stylesheet" />
        <![endif]-->
        <link rel="stylesheet" href="assets/css/ace-skins.min.css" />
        <link rel="stylesheet" href="assets/css/ace-rtl.min.css" />

        <script src="assets/js/ace-extra.min.js"></script>

        <!-- HTML5shiv and Respond.js for IE8 to support HTML5 elements and media queries -->

        <!--[if lte IE 8]>
        <script src="assets/js/html5shiv.min.js"></script>
        <script src="assets/js/respond.min.js"></script>
        <![endif]-->
    </head>


    <body class="no-skin">
        <!-- Main navbar -->
        <?php include 'include/header.php'; ?>
        <!-- /main navbar -->

        <div class="main-container ace-save-state" id="main-container">
            <script type="text/javascript">
                try {
                    ace.settings.loadState('main-container')
                } catch (e) {
                }
            </script>

            <!-- Main sidemenu -->
            <?php include 'include/sidemenu.php'; ?>
            <!-- /main sidemenu -->

            <div class="main-content">
                <div class="main-content-inner">
                    <div class="breadcrumbs ace-save-state" id="breadcrumbs">
                        <ul class="breadcrumb">
                            <li>
                                <i class="ace-icon fa fa-home home-icon"></i>
                                <a href="#">Home</a>
                            </li>

                            <li>
                                <a href="#">Students</a>
                            </li>
                            <li class="active">Data Upload</li>
                        </ul><!-- /.breadcrumb -->

                        <div class="nav-search" id="nav-search">
                            <form class="form-search">
                                <span class="input-icon">
                                    <input type="text" placeholder="Search ..." class="nav-search-input" id="nav-search-input" autocomplete="off" />
                                    <i class="ace-icon fa fa-search nav-search-icon"></i>
                                </span>
                            </form>
                        </div><!-- /.nav-search -->
                    </div>

                    <div class="page-content">

                        <div class="page-header">
                            <h1>
                                Data Upload
                                <small>
                                    <i class="ace-icon fa fa-angle-double-right"></i>
                                    File upload 
                                </small>
                            </h1>
                        </div><!-- /.page-header -->

                        <div class="row">
                            <div class="col-xs-12">
                                <!-- PAGE CONTENT BEGINS -->

                                <?php
                                include_once 'include/DB_Functions.php';
                                $db = new DB_Functions();

                                //Connect to Database
                                //$deleterecords = "TRUNCATE TABLE exp_data"; //empty the table of its current records
                                //mysql_query($deleterecords);
                                function ipCheck() {
                                    if (!empty($_SERVER['HTTP_CLIENT_IP'])) {
                                        $ip = $_SERVER['HTTP_CLIENT_IP'];
                                        //Is it a proxy address
                                    } elseif (!empty($_SERVER['HTTP_X_FORWARDED_FOR'])) {
                                        $ip = $_SERVER['HTTP_X_FORWARDED_FOR'];
                                    } else {
                                        $ip = $_SERVER['REMOTE_ADDR'];
                                    }
                                    return $ip;
                                }

                                $reg_via = "Web";
                                $ip = ipCheck();

                                date_default_timezone_set('Asia/Kolkata');
                                $date_cr = date('m/d/Y');
                                $dt = date("Y/m/d", strtotime($date_cr));
                                $St_Time = "01:00:00";
                                $date = date('m/d/Y h:i:s a', time());
                                $timestamp = strtotime($date);

                                if (isset($_POST['btnupload'])) {

                                    if (is_uploaded_file($_FILES['file']['tmp_name'])) {
                                        //Import uploaded file to Database
                                        //exclude the first row
                                        $csv_file = $_FILES['file']['tmp_name'];
                                        if (($handle = fopen($csv_file, "r")) !== FALSE) {
                                            fgetcsv($handle);
                                            while (($data = fgetcsv($handle, 1000, ",")) !== FALSE) {
                                                $num = count($data);
                                                for ($c = 0; $c < $num; $c++) {
                                                    $col[$c] = $data[$c];
                                                }

                                                $col1 = $col[0];
                                                $col2 = $col[1];
                                                $col3 = $col[2];
                                                $col4 = $col[3];
                                                $col5 = $col[4];
                                                $col6 = $col[5];
                                                $col7 = $col[6];
                                                $col8 = $col[7];

                                                // SQL Query to insert data into DataBase
                                                $query = "INSERT INTO student_details(student_number,student_fname,student_mname,student_lname,student_email,student_phone,student_gender,student_status) VALUES('" . $col1 . "','" . $col2 . "','" . $col3 . "','" . $col4 . "','" . $col5 . "','" . $col6 . "','" . $col7 . "','" . $col8 . "')";
                                                $s = mysql_query($query);
                                            }
                                            fclose($handle);
                                        }
                                        ?>
                                        <script type="text/javascript">
                                            alert("File data successfully imported to database!");
                                            window.location.href = 'student_details_upload.php';
                                        </script>
                                        <?php
                                        mysql_close($connect);
                                    } else {
                                        ?>
                                        <script type="text/javascript">
                                            alert("No File Selected");
                                            window.location.href = 'student_details_upload.php';
                                        </script>
                                        <?php
                                    }
                                } else {
                                    ?>
                                    <div>
                                        <form enctype="multipart/form-data" action="student_details_upload.php" method="post" class="form-horizontal" id="dropzone">
                                            <div class="col-xs-12 col-sm-4">
                                                <input type="file" name="file" class="btn btn-default" data-show-preview="false" data-show-upload="false">
                                            </div>
                                            <div>
                                                <button class="btn btn-info" type="submit" value="submit" name="btnupload" style="width: 300; height: 40">
                                                    Upload CSV
                                                </button>
                                            </div>
                                        </form>
                                    </div>
                                    <?php
                                }
                                ?>

                            </div><!-- /.col -->
                        </div><!-- /.row -->
                    </div><!-- /.page-content -->
                </div>
            </div><!-- /.main-content -->

            <!-- Footer -->
            <?php include 'include/footer.php'; ?>
            <!-- /footer -->

            <a href="#" id="btn-scroll-up" class="btn-scroll-up btn btn-sm btn-inverse">
                <i class="ace-icon fa fa-angle-double-up icon-only bigger-110"></i>
            </a>
        </div><!-- /.main-container -->

        <!-- basic scripts -->

        <!--[if !IE]> -->
        <script src="assets/js/jquery-2.1.4.min.js"></script>

        <!-- <![endif]-->

        <!--[if IE]>
<script src="assets/js/jquery-1.11.3.min.js"></script>
<![endif]-->
        <script type="text/javascript">
                                    if ('ontouchstart' in document.documentElement)
                                        document.write("<script src='assets/js/jquery.mobile.custom.min.js'>" + "<" + "/script>");
        </script>
        <script src="assets/js/bootstrap.min.js"></script>

        <!-- page specific plugin scripts -->
        <script src="assets/js/dropzone.min.js"></script>

        <!-- ace scripts -->
        <script src="assets/js/ace-elements.min.js"></script>
        <script src="assets/js/ace.min.js"></script>

        <!-- inline scripts related to this page -->
        <script type="text/javascript">
                                    jQuery(function ($) {

                                        try {
                                            Dropzone.autoDiscover = false;

                                            var myDropzone = new Dropzone('#dropzone', {
                                                previewTemplate: $('#preview-template').html(),
                                                thumbnailHeight: 120,
                                                thumbnailWidth: 120,
                                                maxFilesize: 0.5,
                                                //addRemoveLinks : true,
                                                //dictRemoveFile: 'Remove',

                                                dictDefaultMessage:
                                                        '<span class="bigger-150 bolder"><i class="ace-icon fa fa-caret-right red"></i> Drop files</span> to upload \
                        <span class="smaller-80 grey">(or click)</span> <br /> \
                        <i class="upload-icon ace-icon fa fa-cloud-upload blue fa-3x"></i>'
                                                ,
                                                thumbnail: function (file, dataUrl) {
                                                    if (file.previewElement) {
                                                        $(file.previewElement).removeClass("dz-file-preview");
                                                        var images = $(file.previewElement).find("[data-dz-thumbnail]").each(function () {
                                                            var thumbnailElement = this;
                                                            thumbnailElement.alt = file.name;
                                                            thumbnailElement.src = dataUrl;
                                                        });
                                                        setTimeout(function () {
                                                            $(file.previewElement).addClass("dz-image-preview");
                                                        }, 1);
                                                    }
                                                }

                                            });


                                            //simulating upload progress
                                            var minSteps = 6,
                                                    maxSteps = 60,
                                                    timeBetweenSteps = 100,
                                                    bytesPerStep = 100000;

                                            myDropzone.uploadFiles = function (files) {
                                                var self = this;

                                                for (var i = 0; i < files.length; i++) {
                                                    var file = files[i];
                                                    totalSteps = Math.round(Math.min(maxSteps, Math.max(minSteps, file.size / bytesPerStep)));

                                                    for (var step = 0; step < totalSteps; step++) {
                                                        var duration = timeBetweenSteps * (step + 1);
                                                        setTimeout(function (file, totalSteps, step) {
                                                            return function () {
                                                                file.upload = {
                                                                    progress: 100 * (step + 1) / totalSteps,
                                                                    total: file.size,
                                                                    bytesSent: (step + 1) * file.size / totalSteps
                                                                };

                                                                self.emit('uploadprogress', file, file.upload.progress, file.upload.bytesSent);
                                                                if (file.upload.progress == 100) {
                                                                    file.status = Dropzone.SUCCESS;
                                                                    self.emit("success", file, 'success', null);
                                                                    self.emit("complete", file);
                                                                    self.processQueue();
                                                                }
                                                            };
                                                        }(file, totalSteps, step), duration);
                                                    }
                                                }
                                            }


                                            //remove dropzone instance when leaving this page in ajax mode
                                            $(document).one('ajaxloadstart.page', function (e) {
                                                try {
                                                    myDropzone.destroy();
                                                } catch (e) {
                                                }
                                            });

                                        } catch (e) {
                                            alert('Dropzone.js does not support older browsers!');
                                        }

                                    });
        </script>
    </body>
</html>
