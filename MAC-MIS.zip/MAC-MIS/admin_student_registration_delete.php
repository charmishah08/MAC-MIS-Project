<?php

include_once 'include/DB_Functions.php';
$db = new DB_Functions();

$student_id = $_GET['r_id'];

$sql_fetch = "SELECT student_email FROM student_details where student_id = '$student_id'";
if (!( $selectRes = mysql_query($sql_fetch) )) {
    echo 'Retrieval of data from Database Failed - #' . mysql_errno() . ': ' . mysql_error();
} else {
    if (mysql_num_rows($selectRes) == 0) {
        echo 'No Rows Returned';
    } else {
        
    }
    while ($row = mysql_fetch_assoc($selectRes)) {
        $student_email = $row['student_email'];
        $sql = mysql_query("DELETE from semester_registered WHERE student_id = '$student_id'");
        $sql_user = mysql_query("DELETE from user WHERE user_email= '$student_email'");
        $result = "DELETE from student_details WHERE student_id = '$student_id'";
        if (mysql_query($result)) {
            ?>
            <script type="text/javascript">
                window.location.href = 'admin_student_list.php';
            </script>
            <?php

        } else {
            ?>
            <script type="text/javascript">
                alert('Could not delete data');
                window.location.href = 'admin_student_list.php';
            </script>
            <?php

        }
    }
}
?>
