<?php
include_once 'include/DB_Functions.php';
$db = new DB_Functions();

$degree_id = $_GET['r_id'];

$sql_fetch = "SELECT student_details.student_id as student_id FROM education_details INNER JOIN student_details ON education_details.student_id = student_details.student_id where degree_id = '$degree_id'";
if (!( $selectRes = mysql_query($sql_fetch) )) {
    echo 'Retrieval of data from Database Failed - #' . mysql_errno() . ': ' . mysql_error();
} else {
    if (mysql_num_rows($selectRes) == 0) {
        echo 'No Rows Returned';
    } else {
        
    }
    while ($row = mysql_fetch_assoc($selectRes)) {
        $student_id = $row['student_id'];

        $sql_user = mysql_query("DELETE from certification_details WHERE degree_id= '$degree_id'");
        $result = "DELETE from education_details WHERE degree_id = '$degree_id'";
        if (mysql_query($result)) {
            ?>
            <script type="text/javascript">
                window.location.href = 'admin_education_details.php?r_id=<?php echo $student_id ?>';
            </script>
            <?php
        } else {
            ?>
            <script type="text/javascript">
                alert('Could not delete data');
                window.location.href = 'admin_student_list.php';
            </script>
            <?php
        }
    }
}
?>
