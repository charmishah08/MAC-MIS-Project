<?php
//
session_start();
include_once 'include/DB_Functions.php';
$users = new DB_Functions();
include_once './internship_jobs_registration_insert.php';
error_reporting(E_ALL ^ E_NOTICE);
?>

<!DOCTYPE html>
<html lang="en">
    <head>
        <meta http-equiv="X-UA-Compatible" content="IE=edge,chrome=1" />
        <meta charset="utf-8" />
        <title>Job Registration</title>

        <meta name="description" content="Static &amp; Dynamic Tables" />
        <meta name="viewport" content="width=device-width, initial-scale=1.0, maximum-scale=1.0" />

        <!-- bootstrap & fontawesome -->
        <link rel="stylesheet" href="assets/css/bootstrap.min.css" />
        <link rel="stylesheet" href="assets/font-awesome/4.5.0/css/font-awesome.min.css" />

        <!-- page specific plugin styles -->

        <!-- text fonts -->
        <link rel="stylesheet" href="assets/css/fonts.googleapis.com.css" />

        <!-- ace styles -->
        <link rel="stylesheet" href="assets/css/ace.min.css" class="ace-main-stylesheet" id="main-ace-style" />

        <!--[if lte IE 9]>
                <link rel="stylesheet" href="assets/css/ace-part2.min.css" class="ace-main-stylesheet" />
        <![endif]-->
        <link rel="stylesheet" href="assets/css/ace-skins.min.css" />
        <link rel="stylesheet" href="assets/css/ace-rtl.min.css" />

        <!-- ace settings handler -->
        <script src="assets/js/ace-extra.min.js"></script>

    </head>

    <body class="no-skin">
        <!-- Main navbar -->
        <?php include 'include/header.php'; ?>
        <!-- /main navbar -->		

        <div class="main-container ace-save-state" id="main-container">
            <script type="text/javascript">
                try {
                    ace.settings.loadState('main-container')
                } catch (e) {
                }
            </script>

            <!-- Main sidemenu -->
            <?php include 'include/sidemenu.php'; ?>
            <!-- /main sidemenu -->

            <div class="main-content">
                <div class="main-content-inner">
                    <div class="breadcrumbs ace-save-state" id="breadcrumbs">
                        <ul class="breadcrumb">
                            <li>
                                <i class="ace-icon fa fa-home home-icon"></i>
                                <a href="#">Home</a>
                            </li>
                            <li class="active">Internship</li>
                            <li class="active">Job List</li>
                            <li class="active">Job Registration</li>

                        </ul><!-- /.breadcrumb -->
                        <div class="page-content">

                            <?php
                            $job_id = $_GET['r_id'];
                            if ($job_id) {
                                $user_sql = mysql_query("SELECT * FROM job_details INNER JOIN company_details ON job_details.job_company_id = company_details.company_id INNER JOIN internship_type ON job_details.job_internship_type_id = internship_type.internship_type_id INNER JOIN job_requirements ON job_details.job_id = job_requirements.job_id INNER JOIN job_responsibilities ON job_details.job_id = job_responsibilities.job_id INNER JOIN job_groups ON job_details.job_group_id = job_groups.job_group_id where job_details.job_id = '$job_id'");
                                $user_row = mysql_fetch_array($user_sql);
                                $job_id = $user_row['job_id'];
                                $job_group = $user_row['job_group_description'];
                                $job_group_id = $user_row['job_group_id'];
                                $company_name = $user_row['company_name'];
                                $job_company_id = $user_row['job_company_id'];
                                $internship_type = $user_row['internship_type'];
                                $job_internship_type_id = $user_row['job_internship_type_id'];
                                $job_position = $user_row['job_position'];
                                $job_description = $user_row['job_description'];
                                $job_salary = $user_row['job_salary'];
                                $job_status = $user_row['job_status'];
                                $job_req_desc = $user_row['job_req_desc'];
                                $job_resp_desc = $user_row['job_resp_desc'];
                                ?>
                                <form class="form-horizontal" role="form" method="post">                                                                                                                                                                                                                                          
                                    <div class="row">
                                        <div class="col-xs-12">
                                            <!-- PAGE CONTENT BEGINS -->

                                            <div class="widget-box">
                                                <div class="widget-header widget-header-blue widget-header-flat">
                                                    <h4 class="widget-title lighter">Update Job Detail</h4>
                                                </div>

                                                <div class="widget-body">
                                                    <div class="widget-main">
                                                        <div id="fuelux-wizard-container">

                                                            <div class="step-content pos-rel">
                                                                <div class="step-pane active" data-step="1">
                                                                    <h3 class="lighter block green">Update the following information</h3>

                                                                    <div class="form-group">
                                                                        <input type="hidden" id="job_id" name="job_id" value="<?php echo $job_id; ?>" placeholder="" class="col-xs-12 col-sm-5" style="width: 350px; height: 40px" required=""/>
                                                                        <label class="control-label col-xs-12 col-sm-3 no-padding-right" for="job group">Job Group:</label>
                                                                        <div class="col-xs-12 col-sm-9">
                                                                            <select id="job_group" name="job_group" class="" style="width: 150; height: 40" data-placeholder="">
                                                                                <option value="<?php echo $job_group_id; ?>"><?php echo $job_group; ?></option>
                                                                                <option value="0">--Select--</option>
                                                                                <?php
                                                                                $list = mysql_query("select * from job_groups order by job_group_id asc");
                                                                                while ($row_list = mysql_fetch_assoc($list)) {
                                                                                    ?>  
                                                                                    <option value="<? echo $row_list['job_group_id']; ?>"><?php echo $row_list['job_group_description']; ?></option>
                                                                                    <?php
                                                                                }
                                                                                ?>
                                                                            </select>
                                                                        </div>
                                                                    </div>  

                                                                    <div class="form-group">
                                                                        <label class="control-label col-xs-12 col-sm-3 no-padding-right" for="company">Company:</label>
                                                                        <div class="col-xs-12 col-sm-9">
                                                                            <select id="company" name="company" class="" style="width: 150; height: 40" data-placeholder="">
                                                                                <option value="<?php echo $job_company_id; ?>"><?php echo $company_name; ?></option>
                                                                                <option value="0">--Select--</option>
                                                                                <?php
                                                                                $list = mysql_query("select * from company_details order by company_id asc");
                                                                                while ($row_list = mysql_fetch_assoc($list)) {
                                                                                    ?>  
                                                                                    <option value="<? echo $row_list['company_id']; ?>"><?php echo $row_list['company_name']; ?></option>
                                                                                    <?php
                                                                                }
                                                                                ?>
                                                                            </select>
                                                                            </select>
                                                                        </div>
                                                                    </div>  

                                                                    <div class="form-group">
                                                                        <label class="control-label col-xs-12 col-sm-3 no-padding-right" for="internship type">Internship Type:</label>
                                                                        <div class="col-xs-12 col-sm-9">
                                                                            <select id="internship_type" name="internship_type" class="" style="width: 150; height: 40" data-placeholder="Choose...">
                                                                                <option value="<?php echo $job_internship_type_id; ?>"><?php echo $internship_type; ?></option>
                                                                                <option value="0">--Select--</option>
                                                                                <?php
                                                                                $list = mysql_query("select * from internship_type order by internship_type_id asc");
                                                                                while ($row_list = mysql_fetch_assoc($list)) {
                                                                                    ?>  
                                                                                    <option value="<? echo $row_list['internship_type_id']; ?>"><?php echo $row_list['internship_type']; ?></option>
                                                                                    <?php
                                                                                }
                                                                                ?>
                                                                            </select>
                                                                        </div>
                                                                    </div>

                                                                    <div class="form-group">
                                                                        <label class="control-label col-xs-12 col-sm-3 no-padding-right" for="position"> Position: </label>

                                                                        <div class="col-xs-12 col-sm-9">
                                                                            <input type="text" id="position" name="position" value="<?php echo $job_position; ?>" placeholder="" class="col-xs-12 col-sm-5" style="width: 350px; height: 40px" required=""/>
                                                                        </div>
                                                                    </div> 

                                                                    <div class="form-group">
                                                                        <label class="control-label col-xs-12 col-sm-3 no-padding-right" for="description"> Description: </label>

                                                                        <div class="col-xs-12 col-sm-9">
                                                                            <textarea class="input-xlarge" name="description" id="description" placeholder="" required=""><?php echo $job_description; ?></textarea>
                                                                        </div>
                                                                    </div> 
                                                                    <!--                                              </div>-->
                                                                    <div class="form-group">
                                                                        <label class="col-sm-3 control-label no-padding-right" for="form-field-responsibilities">Responsibilities:</label>
                                                                        <div class="col-sm-9">
                                                                            <input type="text" required="required" name="responsibilities" value="<?php echo $job_resp_desc; ?>" placeholder="Enter Responsibilities ..." />

                                                                        </div>
                                                                    </div>
                                                                    <div class="form-group">
                                                                        <label class="col-sm-3 control-label no-padding-right" for="form-field-responsibilities"> Requirements: </label>
                                                                        <div class="col-sm-9">
                                                                            <input type="text" name="requirements" id="form-field-requirements" value="<?php echo $job_req_desc; ?>" placeholder="Enter Requirements ..." />

                                                                        </div>
                                                                    </div>

                                                                    <div class="form-group">
                                                                        <label class="control-label col-xs-12 col-sm-3 no-padding-right" for="salary"> Salary: </label>

                                                                        <div class="col-xs-12 col-sm-9">
                                                                            <input type="number" id="salary" name="salary" value="<?php echo $job_salary; ?>" placeholder="" class="col-xs-12 col-sm-5" style="width: 200px; height: 40px" required=""/>
                                                                        </div>
                                                                    </div> 

                                                                    <div class="form-group">
                                                                        <label class="control-label col-xs-12 col-sm-3 no-padding-right" for="status">Status:</label>
                                                                        <div class="col-xs-12 col-sm-9">
                                                                            <select id="status" name="status" class="" style="width: 150; height: 40" data-placeholder="Choose...">
                                                                                <option value="<?php echo $job_status; ?>"><?php echo $job_status; ?></option>
                                                                                <option value="Open">Open</option>
                                                                                <option value="Unopen">Unopen</option>
                                                                                <option value="Close">Close</option>
                                                                            </select>
                                                                        </div>
                                                                    </div>

                                                                    <div class="clearfix form-actions">
                                                                        <div class="col-md-offset-3 col-md-9">
                                                                            <button class="btn btn-info" type="submit" value="submit" name="btn-update" style="width: 300; height: 40">

                                                                                Submit
                                                                            </button>
                                                                            &nbsp; &nbsp; &nbsp;
                                                                            <button class="btn" type="reset" value="reset" style="width: 400; height: 40" >
                                                                                Reset
                                                                            </button>
                                                                        </div>
                                                                    </div>
                                                                </div>
                                                            </div>
                                                        </div>
                                                    </div><!-- /.widget-main -->
                                                </div><!-- /.widget-body -->

                                            </div>
                                        </div><!-- /.col -->
                                    </div><!-- /.row -->
                                </form>
                                <?php
                            } else {
                                ?> 
                                <form class="form-horizontal" role="form" method="post">                                                                                                                                                                                                                                          
                                    <div class="row">
                                        <div class="col-xs-12">
                                            <!-- PAGE CONTENT BEGINS -->

                                            <div class="widget-box">
                                                <div class="widget-header widget-header-blue widget-header-flat">
                                                    <h4 class="widget-title lighter">Add Job Detail</h4>
                                                </div>

                                                <div class="widget-body">
                                                    <div class="widget-main">
                                                        <div id="fuelux-wizard-container">

                                                            <div class="step-content pos-rel">
                                                                <div class="step-pane active" data-step="1">
                                                                    <h3 class="lighter block green">Enter the following information</h3>

                                                                    <div class="form-group">
                                                                        <label class="control-label col-xs-12 col-sm-3 no-padding-right" for="job group">Job Group:</label>
                                                                        <div class="col-xs-12 col-sm-9">
                                                                            <select id="job_group" name="job_group" class="" style="width: 150; height: 40" data-placeholder="">
                                                                                <option value="0">--Select--</option>
                                                                                <?php
                                                                                $list = mysql_query("select * from job_groups order by job_group_id asc");
                                                                                while ($row_list = mysql_fetch_assoc($list)) {
                                                                                    ?>  
                                                                                    <option value="<? echo $row_list['job_group_id']; ?>"><?php echo $row_list['job_group_description']; ?></option>
                                                                                    <?php
                                                                                }
                                                                                ?>
                                                                            </select>
                                                                        </div>
                                                                    </div>  

                                                                    <div class="form-group">
                                                                        <label class="control-label col-xs-12 col-sm-3 no-padding-right" for="company">Company:</label>
                                                                        <div class="col-xs-12 col-sm-9">
                                                                            <select id="company" name="company" class="" style="width: 150; height: 40" data-placeholder="">
                                                                                <option value="0">--Select--</option>
                                                                                <?php
                                                                                $list = mysql_query("select * from company_details order by company_id asc");
                                                                                while ($row_list = mysql_fetch_assoc($list)) {
                                                                                    ?>  
                                                                                    <option value="<? echo $row_list['company_id']; ?>"><?php echo $row_list['company_name']; ?></option>
                                                                                    <?php
                                                                                }
                                                                                ?>
                                                                            </select>
                                                                            </select>
                                                                        </div>
                                                                    </div>  

                                                                    <div class="form-group">
                                                                        <label class="control-label col-xs-12 col-sm-3 no-padding-right" for="internship type">Internship Type:</label>
                                                                        <div class="col-xs-12 col-sm-9">
                                                                            <select id="internship_type" name="internship_type" class="" style="width: 150; height: 40" data-placeholder="Choose...">
                                                                                <option value="0">--Select--</option>
                                                                                <?php
                                                                                $list = mysql_query("select * from internship_type order by internship_type_id asc");
                                                                                while ($row_list = mysql_fetch_assoc($list)) {
                                                                                    ?>  
                                                                                    <option value="<? echo $row_list['internship_type_id']; ?>"><?php echo $row_list['internship_type']; ?></option>
                                                                                    <?php
                                                                                }
                                                                                ?>
                                                                            </select>
                                                                        </div>
                                                                    </div>

                                                                    <div class="form-group">
                                                                        <label class="control-label col-xs-12 col-sm-3 no-padding-right" for="position"> Position: </label>

                                                                        <div class="col-xs-12 col-sm-9">
                                                                            <input type="text" id="position" name="position" placeholder="" class="col-xs-12 col-sm-5" style="width: 350px; height: 40px" required=""/>
                                                                        </div>
                                                                    </div> 

                                                                    <div class="form-group">
                                                                        <label class="control-label col-xs-12 col-sm-3 no-padding-right" for="description"> Description: </label>

                                                                        <div class="col-xs-12 col-sm-9">
                                                                            <textarea class="input-xlarge" name="description" id="description" placeholder="" required=""></textarea>
                                                                        </div>
                                                                    </div> 
                                                                    <!--                                              </div>-->
                                                                    <div class="form-group">
                                                                        <label class="col-sm-3 control-label no-padding-right" for="form-field-responsibilities">Responsibilities:</label>
                                                                        <div class="col-sm-9">
                                                                            <input type="text" required="required" name="responsibilities" value="" placeholder="Enter Responsibilities ..." />

                                                                        </div>
                                                                    </div>
                                                                    <div class="form-group">
                                                                        <label class="col-sm-3 control-label no-padding-right" for="form-field-responsibilities"> Requirements: </label>
                                                                        <div class="col-sm-9">
                                                                            <input type="text" name="requirements" id="form-field-requirements" value="" placeholder="Enter Requirements ..." />

                                                                        </div>
                                                                    </div>

                                                                    <div class="form-group">
                                                                        <label class="control-label col-xs-12 col-sm-3 no-padding-right" for="salary"> Salary: </label>

                                                                        <div class="col-xs-12 col-sm-9">
                                                                            <input type="number" id="salary" name="salary" placeholder="" class="col-xs-12 col-sm-5" style="width: 200px; height: 40px" required=""/>
                                                                        </div>
                                                                    </div> 

                                                                    <div class="form-group">
                                                                        <label class="control-label col-xs-12 col-sm-3 no-padding-right" for="status">Status:</label>
                                                                        <div class="col-xs-12 col-sm-9">
                                                                            <select id="status" name="status" class="" style="width: 150; height: 40" data-placeholder="Choose...">
                                                                                <option value="Open">Open</option>
                                                                                <option value="Unopen" selected="">Unopen</option>
                                                                                <option value="Close">Close</option>
                                                                            </select>
                                                                        </div>
                                                                    </div>
                                                                    <div class="form-group">
                                                                        <label class="col-sm-2 control-label no-padding-right" for="form-field-responsibilities"></label>
                                                                        <div class="col-sm-10">
                                                                            <table id="dynamic-table" class="table table-striped table-bordered table-hover">
                                                                                <thead>
                                                                                    <tr>
                                                                                        <th class="center">

                                                                                        </th>
                                                                                        <th>ID</th>
                                                                                        <th>Name</th>
                                                                                        <th>Email</th>
                                                                                        <th>Phone</th>
                                                                                        <th>Gender</th>
                                                                                    </tr>
                                                                                </thead>

                                                                                <tbody>
                                                                                    <?php
                                                                                    $list = mysql_query("select * from student_details order by student_id asc");
                                                                                    while ($row_list = mysql_fetch_assoc($list)) {
                                                                                        ?>
                                                                                        <tr>
                                                                                            <td class="center">
                                                                                                <label class="pos-rel">
                                                                                                    <input type="checkbox" name="users[]" class="ace" checked="checked"/>
                                                                                                    <span class="lbl"></span>
                                                                                                </label>
                                                                                            </td>

                                                                                            <td>
                                                                                                <a href="#"><?php echo $row_list['student_number']; ?></a>
                                                                                            </td>
                                                                                            <td><?php echo $row_list['student_fname'] . ' ' . $row_list['student_mname'] . ' ' . $row_list['student_lname']; ?></td>
                                                                                            <td><?php echo $row_list['student_email']; ?></td>
                                                                                            <td><?php echo $row_list['student_phone']; ?></td>
                                                                                            <td><?php echo $row_list['student_gender']; ?></td>
                                                                                        </tr>
                                                                                        <?php
                                                                                    }
                                                                                    ?>
                                                                                </tbody>
                                                                            </table>
                                                                        </div>
                                                                    </div>
                                                                    <div class="clearfix form-actions">
                                                                        <div class="col-md-offset-3 col-md-9">
                                                                            <button class="btn btn-info" type="submit" value="submit" name="btn-register" style="width: 300; height: 40">

                                                                                Submit
                                                                            </button>
                                                                            &nbsp; &nbsp; &nbsp;
                                                                            <button class="btn" type="reset" value="reset" style="width: 400; height: 40" >
                                                                                Reset
                                                                            </button>
                                                                        </div>
                                                                    </div>

                                                                </div>
                                                            </div>
                                                        </div>
                                                    </div><!-- /.widget-main -->
                                                </div><!-- /.widget-body -->

                                            </div>
                                        </div><!-- /.col -->
                                    </div><!-- /.row -->
                                </form>
                            </div><!-- /.page-content -->
                        </div>
                    </div><!-- /.main-content -->

                    <?php
                }
                ?>
                <!-- Footer -->
                <?php include 'include/footer.php'; ?>
                <!-- /footer -->

                <a href="#" id="btn-scroll-up" class="btn-scroll-up btn btn-sm btn-inverse">
                    <i class="ace-icon fa fa-angle-double-up icon-only bigger-110"></i>
                </a>
            </div><!-- /.main-container -->

            <!-- basic scripts -->

            <!--[if !IE]> -->
            <script src="assets/js/jquery-2.1.4.min.js"></script>

            <!-- <![endif]-->

            <!--[if IE]>
            <script src="assets/js/jquery-1.11.3.min.js"></script>
            <![endif]-->
            <script type="text/javascript">
                            if ('ontouchstart' in document.documentElement)
                                document.write("<script src='assets/js/jquery.mobile.custom.min.js'>" + "<" + "/script>");
            </script>
            <script src="assets/js/bootstrap.min.js"></script>

            <!-- page specific plugin scripts -->
            <script src="assets/js/wizard.min.js"></script>
            <script src="assets/js/jquery.validate.min.js"></script>
            <script src="assets/js/jquery-additional-methods.min.js"></script>
            <script src="assets/js/bootbox.js"></script>
            <script src="assets/js/jquery.maskedinput.min.js"></script>
            <script src="assets/js/select2.min.js"></script>

            <!-- ace scripts -->
            <script src="assets/js/ace-elements.min.js"></script>
            <script src="assets/js/ace.min.js"></script>

            <!-- inline scripts related to this page -->
            <script type="text/javascript">
                            jQuery(function ($) {

                                $('[data-rel=tooltip]').tooltip();

                                $('.select2').css('width', '200px').select2({allowClear: true})
                                        .on('change', function () {
                                            $(this).closest('form').validate().element($(this));
                                        });


                                var $validation = false;
                                $('#fuelux-wizard-container')
                                        .ace_wizard({
                                            //step: 2 //optional argument. wizard will jump to step "2" at first
                                            //buttons: '.wizard-actions:eq(0)'
                                        })
                                        .on('actionclicked.fu.wizard', function (e, info) {
                                            if (info.step == 1 && $validation) {
                                                if (!$('#validation-form').valid())
                                                    e.preventDefault();
                                            }
                                        })
                                        //.on('changed.fu.wizard', function() {
                                        //})
                                        .on('finished.fu.wizard', function (e) {
                                            bootbox.dialog({
                                                message: "Thank you! Your information was successfully saved!",
                                                buttons: {
                                                    "success": {
                                                        "label": "OK",
                                                        "className": "btn-sm btn-primary"
                                                    }
                                                }
                                            });
                                        }).on('stepclick.fu.wizard', function (e) {
                                    //e.preventDefault();//this will prevent clicking and selecting steps
                                });


                                //jump to a step
                                /**
                                 var wizard = $('#fuelux-wizard-container').data('fu.wizard')
                                 wizard.currentStep = 3;
                                 wizard.setState();
                                 */

                                //determine selected step
                                //wizard.selectedItem().step



                                //hide or show the other form which requires validation
                                //this is for demo only, you usullay want just one form in your application
                                $('#skip-validation').removeAttr('checked').on('click', function () {
                                    $validation = this.checked;
                                    if (this.checked) {
                                        $('#sample-form').hide();
                                        $('#validation-form').removeClass('hide');
                                    } else {
                                        $('#validation-form').addClass('hide');
                                        $('#sample-form').show();
                                    }
                                })



                                //documentation : http://docs.jquery.com/Plugins/Validation/validate


                                $.mask.definitions['~'] = '[+-]';
                                $('#phone').mask('(999) 999-9999');

                                jQuery.validator.addMethod("phone", function (value, element) {
                                    return this.optional(element) || /^\(\d{3}\) \d{3}\-\d{4}( x\d{1,6})?$/.test(value);
                                }, "Enter a valid phone number.");

                                $('#validation-form').validate({
                                    errorElement: 'div',
                                    errorClass: 'help-block',
                                    focusInvalid: false,
                                    ignore: "",
                                    rules: {
                                        email: {
                                            required: true,
                                            email: true
                                        },
                                        password: {
                                            required: true,
                                            minlength: 5
                                        },
                                        password2: {
                                            required: true,
                                            minlength: 5,
                                            equalTo: "#password"
                                        },
                                        name: {
                                            required: true
                                        },
                                        phone: {
                                            required: true,
                                            phone: 'required'
                                        },
                                        url: {
                                            required: true,
                                            url: true
                                        },
                                        comment: {
                                            required: true
                                        },
                                        state: {
                                            required: true
                                        },
                                        platform: {
                                            required: true
                                        },
                                        subscription: {
                                            required: true
                                        },
                                        gender: {
                                            required: true,
                                        },
                                        agree: {
                                            required: true,
                                        }
                                    },
                                    messages: {
                                        email: {
                                            required: "Please provide a valid email.",
                                            email: "Please provide a valid email."
                                        },
                                        password: {
                                            required: "Please specify a password.",
                                            minlength: "Please specify a secure password."
                                        },
                                        state: "Please choose state",
                                        subscription: "Please choose at least one option",
                                        gender: "Please choose gender",
                                        agree: "Please accept our policy"
                                    },
                                    highlight: function (e) {
                                        $(e).closest('.form-group').removeClass('has-info').addClass('has-error');
                                    },
                                    success: function (e) {
                                        $(e).closest('.form-group').removeClass('has-error');//.addClass('has-info');
                                        $(e).remove();
                                    },
                                    errorPlacement: function (error, element) {
                                        if (element.is('input[type=checkbox]') || element.is('input[type=radio]')) {
                                            var controls = element.closest('div[class*="col-"]');
                                            if (controls.find(':checkbox,:radio').length > 1)
                                                controls.append(error);
                                            else
                                                error.insertAfter(element.nextAll('.lbl:eq(0)').eq(0));
                                        } else if (element.is('.select2')) {
                                            error.insertAfter(element.siblings('[class*="select2-container"]:eq(0)'));
                                        } else if (element.is('.chosen-select')) {
                                            error.insertAfter(element.siblings('[class*="chosen-container"]:eq(0)'));
                                        } else
                                            error.insertAfter(element.parent());
                                    },
                                    submitHandler: function (form) {
                                    },
                                    invalidHandler: function (form) {
                                    }
                                });




                                $('#modal-wizard-container').ace_wizard();
                                $('#modal-wizard .wizard-actions .btn[data-dismiss=modal]').removeAttr('disabled');


                                /**
                                 $('#date').datepicker({autoclose:true}).on('changeDate', function(ev) {
                                 $(this).closest('form').validate().element($(this));
                                 });
                     
                                 $('#mychosen').chosen().on('change', function(ev) {
                                 $(this).closest('form').validate().element($(this));
                                 });
                                 */


                                $(document).one('ajaxloadstart.page', function (e) {
                                    //in ajax mode, remove remaining elements before leaving page
                                    $('[class*=select2]').remove();
                                });
                            })
            </script>
    </body>
</html>
