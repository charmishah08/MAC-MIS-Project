<?php

include_once 'include/DB_Functions.php';
$db = new DB_Functions();

if (isset($_POST['btn-register'])) {
    $job_grp = $_POST['job_group'];
    $job_cmp = $_POST['company'];
    $job_intType = $_POST['internship_type'];
    $job_position = $_POST['position'];
    $job_description = $_POST['description'];
    $job_salary = $_POST['salary'];
    $job_status = $_POST['status'];

    $job_resp = $_POST['responsibilities'];
    $rowCount_job_mail = count($_POST["users"]);
    $job_req = $_POST['requirements'];
    //$rowCount_job_req = count($_POST["chk_req"]);

    $result = $db->insertJobData($job_grp, $job_cmp, $job_intType, $job_position, $job_description, $job_salary, $job_status);
    mysql_query($result);
    $result_job_id = mysql_query("SELECT Max(job_details.job_id) as job_id FROM job_details");
    $data_job_id = mysql_fetch_array($result_job_id);
    $max_job_id = $data_job_id['job_id'];

    $result_job_resp = $db->insertJobResponsibility($job_resp, $max_job_id);
    $result_job_req = $db->insertJobRequirements($job_req, $max_job_id);

    if ($job_status == 'Open') {
        for ($i = 0; $i < $rowCount_job_mail; $i++) {
            $user_idt = $_POST["users"][$i];
            $result_stu_data = mysql_query("SELECT * from student_details WHERE student_id = '$user_idt'");
            $row = mysql_fetch_array($result_stu_data);

            $to = $row['student_email'];
            require_once 'mailer/Send_Mail.php';
            $subject = "Job Posting";
            $body = "<div>" . $row['student_fname'] . "Job Posting For" . $job_position . $job_description;
            Send_Mail($to, $subject, $body);
        }
    }
    
    if (mysql_query($result_job_resp) && mysql_query($result_job_req)) {
        ?>
        <script type="text/javascript">
            alert('Inserted..');
            window.location.href = 'internship_jobs.php';
        </script>
        <?php

    } else {
        ?>
        <script type="text/javascript">
            alert('error occured while inserting your data');
        </script>
        <?php

    }
}

if (isset($_POST['btn-update'])) {
    $job_id = $_POST['job_id'];
    $job_grp = $_POST['job_group'];
    $job_cmp = $_POST['company'];
    $job_intType = $_POST['internship_type'];
    $job_position = $_POST['position'];
    $job_description = $_POST['description'];
    $job_salary = $_POST['salary'];
    $job_status = $_POST['status'];

    $job_resp = $_POST['responsibilities'];
    //$rowCount_job_mail = count($_POST["users"]);
    $job_req = $_POST['requirements'];

    $result = $db->updateJobData($job_grp, $job_cmp, $job_intType, $job_position, $job_description, $job_salary, $job_status, $job_id);

    $result_job_resp = $db->updateJobResponsibility($job_resp, $job_id);
    $result_job_req = $db->updateJobRequirements($job_req, $job_id);
       
    if (mysql_query($result) && mysql_query($result_job_resp) && mysql_query($result_job_req)) {
        ?>
        <script type="text/javascript">
            alert('Updated..');
            window.location.href = 'internship_jobs.php';
        </script>
        <?php

    } else {
        ?>
        <script type="text/javascript">
            alert('error occured while updating your data');
        </script>
        <?php

    }
}
