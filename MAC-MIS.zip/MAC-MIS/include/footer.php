<div class="footer">
    <div class="footer-inner">
        <div class="footer-content">
            <span class="bigger-120">
                <span class="blue bolder">MAC-MIS</span>
                Application &copy; 2017-2018
            </span>

            &nbsp; &nbsp;
            
        </div>
    </div>
</div>