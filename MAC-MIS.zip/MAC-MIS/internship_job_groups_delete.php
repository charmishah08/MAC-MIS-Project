<?php

include_once 'include/DB_Functions.php';
$db = new DB_Functions();

$job_group_id = $_GET['r_id'];

$sql = mysql_query("DELETE from job_groups WHERE job_group_id = '$job_group_id'");

if ($sql) {
    ?>
    <script type="text/javascript">
        alert("Deleted data successfully");
        window.location.href = 'internship_job_groups.php';
    </script>
    <?php

} else {
    ?>
    <script type="text/javascript">
        alert('Could not delete data');
        window.location.href = 'internship_job_groups.php';
    </script>
    <?php

}
?>
